# Lorina Birthday Universe ❤️

Open `index.html` in a browser to preview the website.

The five memory photos are inside the `images` folder.
To publish on GitHub Pages, upload `index.html` and the entire `images` folder to the repository.
